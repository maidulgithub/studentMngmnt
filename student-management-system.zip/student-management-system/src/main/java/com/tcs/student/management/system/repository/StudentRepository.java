package com.tcs.student.management.system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.student.management.system.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long>{

}
