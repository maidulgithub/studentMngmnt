package com.tcs.student.management.system.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.student.management.system.entity.Student;
import com.tcs.student.management.system.repository.StudentRepository;
import com.tcs.student.management.system.service.StudentService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public List<Student> getAllStudents() {
		log.info("Inside getAllStudents method of StudentServiceImpl");
		return studentRepository.findAll();
	}

	@Override
	public Student saveStudent(Student student) {
		log.info("Inside saveStudent method of StudentServiceImpl");
		return studentRepository.save(student);
	}

	@Override
	public Student getStudentById(Long id) {
		log.info("Inside getStudentById method of StudentServiceImpl");
		return studentRepository.findById(id).get();
	}

	@Override
	public Student updateStudent(Student student) {
		log.info("Inside updateStudent method of StudentServiceImpl");
		return studentRepository.save(student);
	}

	@Override
	public void deleteStudentById(Long id) {
		log.info("Inside deleteStudentById method of StudentServiceImpl");
		studentRepository.deleteById(id);	
	}

}
