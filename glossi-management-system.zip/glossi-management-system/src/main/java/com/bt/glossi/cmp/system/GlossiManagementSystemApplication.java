package com.bt.glossi.cmp.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlossiManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlossiManagementSystemApplication.class, args);
	}
}