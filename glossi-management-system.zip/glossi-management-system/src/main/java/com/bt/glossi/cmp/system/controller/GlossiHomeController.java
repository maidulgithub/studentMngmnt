package com.bt.glossi.cmp.system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.bt.glossi.cmp.system.entity.Student;
//import com.bt.glossi.cmp.system.service.GlossiService;


import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class GlossiHomeController {
	
	/*
	 * @Autowired private GlossiService glossiService;
	 */
	
	// handler method to handle list students and return mode and view
	@GetMapping("/glossi")
	public String listStudents(Model model) {
		log.info("Inside listStudents method of StudentController");
		//model.addAttribute("students", glossiService.getAllStudents());
		return "glossi";
	}

}
